import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Background extends JPanel{
	
	private Image bg;

    public Background() 
    {
        bg = (new ImageIcon("Lanes2.png")).getImage();
    }

    /*protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // paint the background image and scale it to fill the entire space
        g.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
    }*/
    
    @Override
    public void paint(Graphics g)
    {
    	super.paint(g);
    	Graphics2D g2d = (Graphics2D) g;
		
		g2d.drawImage(bg, 0, 0, 800, 700, this);
    }
}
