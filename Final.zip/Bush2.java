import java.awt.Image;
import javax.swing.ImageIcon;

public class Bush2 extends Obstacle{
	
	public Bush2(int x, int y, double velX, double velY, String fileName) 
	{
		super(x, y, velX, velY, fileName);
	}
	
}
