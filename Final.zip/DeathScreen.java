import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.LayoutStyle;
import javax.swing.WindowConstants;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Eric Florin
 */
public class DeathScreen extends JPanel {

	GameLoop w;
	JButton exit = new JButton("Exit");
	JButton restart = new JButton("Restart");
//	Score getScore = new Score();
//	private int score = getScore.toInt();
	JLabel loseText = new JLabel();
	JLabel score = new JLabel();
	
	public DeathScreen(GameLoop w)
	{
//switched the sequence!!
		this.w = w;
		gui();				
	}
	
	public void gui()
	{
		setLayout(null);
		Font use = new Font("Arial", Font.PLAIN, 36);
		
		setBackground(Color.black);
		/*
		restart.setBounds(250, 400, 100, 40);
		restart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                restartAction(evt);
            }
        });
		*/
		exit.setBounds(350, 400, 100, 40);
		exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                exitAction(evt);
            }
        });
		
		
		loseText.setFont(use);
		loseText.setForeground(Color.WHITE);
		loseText.setText("Game Over");
		loseText.setBounds(300, 200, 600, 100);
		
		
		score.setFont(use);
		score.setForeground(Color.WHITE);

		score.setText("Score: " + w.returnScore());
		score.setBounds(300, 250, 600, 100);
		
		//g.drawString("You're dead", 200, 200);
		//g.drawString("Score: ", 200, 300);
		add(loseText);
		add(score);
		add(exit);
		add(restart);

	}

	public void updateScore(){
		score.setText("Score: " + w.returnScore());
	}
	
	private void exitAction (ActionEvent evt)
	{
		System.exit(0);
	}
	/*
	private void restartAction(ActionEvent evt)
	{
		m.playGame();
	}
	*/
}
