import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GameLoop extends JPanel implements ActionListener, KeyListener{
	
	//middle lane: xStart = 420; xEnd = 80
	//left lane: xStart = 220; xEnd = 280;
	//right lane: xStart = 620; xEnd = 480;
	
	private Background bgrd;
	private Timer gameClock;
	private Runner runner;
	private Main m;
	
	int xC, yC=20;
	int cX, cY; 
	int rX;
	int xV = -3, yV = 9;
	private int clockReps;
	boolean isAlive;

	Score sc = new Score();
	JPanel bg = new Background();
	
	ArrayList<Obstacle> obstacles;
	
	Image bgimg=(new ImageIcon("Lanes3.png")).getImage();
	
	public GameLoop(Main w)
	{
		addKeyListener(this);
		setFocusable(true);

		add(sc);
		add(bg); 
		
		rX = 280;
		runner = new Runner(rX, 550);
		
    	obstacles = new ArrayList<Obstacle>();
    	sendObstacle();
    	
    	xC = 420;
    	clockReps = 0;
		
		gameClock = new Timer(35,this);
		gameClock.setInitialDelay(0);
		gameClock.start();
		
		m = w;
    }
	
	private void moveObstacle()
	{		
		for (int i = 0; i < obstacles.size();) 
		{
			Obstacle o = obstacles.get(i);
			if ((o.getX() + o.getWidth()) < 0 || o.getY() > this.getHeight()) 
			{
				obstacles.remove(i);
			} else 
			{
				o.moveByAmount(xV, yV);
				i++;
				cX = o.getX() + o.getWidth()/2;
				cY = o.getY() + o.getHeight()/2;
				//wSystem.out.println("score: "+sc.getScore() +"; obstacle "+i+" ("+cX+","+cY+") and runner ("+runner.getX() + ","+runner.getY()+","+runner.getWidth()+","+runner.getHeight()+")");
				if(runner.isPointInImage(cX, cY)==true)
				{
					gameClock.stop();
					m.changeToDeathScreen();
//									myFrame.dispatchEvent(new WindowEvent(myFrame, WindowEvent.WINDOW_CLOSING));
//									Main.changeToDeathScreen();
				}
			}
		}
	}
	
	public void sendObstacle()
	{
		Obstacle current = null;
		Obstacle bush1 = new Bush1(xC, yC, xV, yV, "bush-clipart-soft-bush-md.png");
		Obstacle bush2 = new Bush2(xC, yC, xV, yV, "4872_render_George_Bush.png");		
		Obstacle train = new Train(xC, yC, xV, yV, "302px-TrainClipart.svg.png");
		Obstacle gate = new Gate(xC, yC, xV, yV, "png_archway_by_paradise234-d5ld4hk.png");
		Obstacle house = new House(xC, yC, xV, yV, "free-vector-house-clip-art_106431_House_clip_art_medium.png");
		
		int o = (int)(Math.random()*5);		
		if(o==0)
		{
			current = bush1;
		}
		else if(o==1)
		{
			current = house;
		}
		else if(o==2)
		{
			current = train;
		}
		else
			if(o==3)
		{
			current = gate;
		}
		else if(o==4)
		{
			current = bush2;
		}
		/*
		int s = sc.toInt();
		if(s % 9 == 9000)
		{
			current.increaseSpeed(2.0);
		}*/
		
		int l = (int)(Math.random() * 3);
		if(l==1)
		{
			xC = 255;
		}
		else if(l==2)
		{
			xC = 465;
		}
		else
		{
			xC = 635;
		}
		
		obstacles.add(current);
		repaint();
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawImage(bgimg, 0, 0, 800, 700, this);
		g.setColor(Color.BLACK);
		g.drawString(sc.getScore(), 10, 10);
		
		for (int i = 0; i < obstacles.size(); i++) {
			obstacles.get(i).draw(g, this);
		}
		
		runner.draw(g, this);
		
	}

	public void actionPerformed(ActionEvent e) 
	{
		clockReps++;
		
		if (clockReps % 4 == 0) {
			sc.updateScore();
		}
		
			if(clockReps<200)
			{
				if (clockReps %80 == 0)
				{
					sendObstacle();
				}
			}
			else if(clockReps>200 && clockReps < 300)
			{
				if(clockReps % 40 == 0)
				{
					sendObstacle();
				}
			}
			else if(clockReps>300 && clockReps <400)
			{
				if(clockReps % 20 == 0)
				{
					sendObstacle();
				}
			}
			else if(clockReps > 400 && clockReps < 600)
			{
				if(clockReps % 10 == 0)
				{
					sendObstacle();
				}
			}
			else
			{
				if(clockReps%5==0)
				{
					sendObstacle();
				}
			}
			if(clockReps % 50 == 0)
			{
				xV -= 1;
				yV +=3;
			}
		
		moveObstacle();
		
		repaint();
	}
	
	public String returnScore()
	{
//not the toString!!!\
		return sc.getScore();
	}
	
	public void runnerMoveLeft()
	{
		runner.left();
		repaint();
	}
	
	public void runnerMoveRight()
	{
		runner.right();
		repaint();
	}
	
	public void keyPressed(KeyEvent e)
	{
		int code = e.getKeyCode();
		
		if(code == KeyEvent.VK_LEFT)
		{
			runner.left();
		}
		else if(code == KeyEvent.VK_RIGHT)
		{
			runner.right();
		}
		
		repaint();
	}
	

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
