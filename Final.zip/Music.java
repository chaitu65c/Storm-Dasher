import java.io.File;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;



public class Music {

	File beep;
	Clip clip;
	private String fileName;
	
	
	
	public Music()
	{

		 beep = new File("darudesandstorm.au");
	}
	
	public void play()
	{
		  playTimer(beep);
	}
	
	public void stop()
	{
		clip.stop();
		clip.close();
	}
	
	public void playTimer(File sound)
	  {
		  try
		  {
			  clip = AudioSystem.getClip();
			  clip.open(AudioSystem.getAudioInputStream(sound));
			  clip.loop(Clip.LOOP_CONTINUOUSLY);
			  clip.start();
			  
		  }
		  catch(Exception e)
		  {
			  
		  }
	  }
	
}
