import java.awt.CardLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;


public class Main extends JFrame implements KeyListener {

	JPanel menus, game, deathScreen;
    CardLayout cl;
    private GameLoop gamePanel;
    Music song = new Music();
	//Changes made: added throws InterruptedException

    
    DeathScreen loseScreen ;

	public Main() throws InterruptedException
	{
		
		super("Storm Runner");
		
		setBounds(50, 50, 800, 700);
	    setDefaultCloseOperation(3);
	    setResizable(false);
	    
	    menus = new JPanel();
	    game = new JPanel();
	    deathScreen = new JPanel();
	    
	    cl = new CardLayout();
	    menus.setLayout(cl);
	    
	    IntroScreen intro = new IntroScreen(this);
	    Instructions instructions = new Instructions(this);
	    gamePanel = new GameLoop(this);
	    loseScreen = new DeathScreen(gamePanel);
	    
	    //game.add(gamePanel);
	    
	    menus.add(intro, "1");
	    menus.add(instructions, "2");
	    menus.add(gamePanel, "3");
	    menus.add(loseScreen, "4");
	    
	    //deathScreen.add(screen);
		//menus.add(panel2, " 2");
	    add(menus);
	    
	    setVisible(true);
		
	}
	
	
	
	 public void playGame()
	 {
		 ((CardLayout)menus.getLayout()).show(menus, "3");
		 requestFocus();
		 song.play();
	 }
	 	
	 public void changeToInstructions()
	 {
		 ((CardLayout)menus.getLayout()).show(menus, "2");
		 requestFocus();
	 }
	
	public void changeFromInstructionsToMenu()
	{
		((CardLayout)menus.getLayout()).show(menus, "1");
		 requestFocus();
	}
	 
	public void changeToDeathScreen()
	{
	loseScreen.updateScore();
		((CardLayout)menus.getLayout()).show(menus, "4");
		 requestFocus();
		 song.stop();
	}
	
	public void restartFromDeathScreen()
	{
		((CardLayout)menus.getLayout()).show(menus, "3");
		 requestFocus();
		 song.play();
		
	}
	
	public static void main(String[] args) throws InterruptedException
	{
		Main w = new Main();
		w.addKeyListener(w);
		//JFrame frame = new JFrame("Storm Runners");
	 //   frame.getContentPane().add(w);		
	//	frame.setBounds(100, 100, 800, 700);
	//	frame.setResizable(true);
	//	frame.setVisible(true);
	//	frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int code = e.getKeyCode();
		
		
		if (code == KeyEvent.VK_LEFT)
		{
			gamePanel.runnerMoveLeft();
		}
		if (code == KeyEvent.VK_RIGHT)	
		{
			gamePanel.runnerMoveRight();
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
