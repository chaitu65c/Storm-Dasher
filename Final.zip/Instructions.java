import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Eric
 */
public class Instructions extends JPanel {

	Main m;
	
    public Instructions(Main w) {
        initComponents();
        m = w;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        backToMenu = new JButton();
        playGame = new JButton();
        mainObjective = new JLabel();
        avoid = new JLabel();

        backToMenu.setText("Back to Menu");
        backToMenu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                backToMenuActionPerformed(evt);
            }
        });

        playGame.setText("Play Game");
        playGame.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                playGameActionPerformed(evt);
            }
        });

        mainObjective.setFont(new Font("Arial", 0, 48)); // NOI18N
        mainObjective.setText("Avoid the obstacles!");

        avoid.setFont(new Font("Arial", 0, 24)); // NOI18N
        avoid.setText("Press left and right to switch lanes and avoid all obstacles");

        GroupLayout layout = new GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(232, 232, 232)
                        .addComponent(backToMenu, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(playGame, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(mainObjective)
                            .addComponent(avoid))))
                .addContainerGap(112, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                    .addComponent(playGame, GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                    .addComponent(backToMenu, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(65, 65, 65)
                .addComponent(mainObjective)
                .addGap(26, 26, 26)
                .addComponent(avoid)
                .addContainerGap(568, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void backToMenuActionPerformed(ActionEvent evt) {//GEN-FIRST:event_backToMenuActionPerformed
        // TODO add your handling code here:
    	m.changeFromInstructionsToMenu();
    }//GEN-LAST:event_backToMenuActionPerformed

    private void playGameActionPerformed(ActionEvent evt) {//GEN-FIRST:event_playGameActionPerformed
        // TODO add your handling code here:
    	m.playGame();
    }//GEN-LAST:event_playGameActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backToMenu;
    private javax.swing.JLabel mainObjective;
    private javax.swing.JLabel avoid;
    private javax.swing.JButton playGame;
    // End of variables declaration//GEN-END:variables
}
