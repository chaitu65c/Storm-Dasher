import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Graphics;
import java.awt.image.ImageObserver;

import javax.swing.ImageIcon;

public class Obstacle extends MovingImage
{
	
	//private Image picture;
	private int x, y;
	private double velX= 2.0, velY=2.0;
	private static int w=130, h=120;
	
	public Obstacle(int x, int y, double velX, double velY, String image) 
	{
		super(image, x, y, w, h);

		this.velX = velX;
		this.velY = velY;

	}

	
	public void increaseSpeed(double dV)
	{
		velX -= dV * Math.sin(15);
		velY += dV * Math.cos(15);
		
	}
	
	public void updatePosition(int dT)
	{
        moveByAmount(-(int)(velX * dT), (int)(velY * dT));
		y = y + (int)(velY * dT);
	}
	
}
