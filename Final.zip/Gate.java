import java.awt.Image;
import javax.swing.ImageIcon;

public class Gate extends Obstacle{
	
	public Gate(int x, int y, double velX, double velY, String fileName) 
	{
		super(x, y, velX, velY, fileName);
	}
	
}
