import java.awt.Image;
import javax.swing.ImageIcon;

public class Bush1 extends Obstacle{
	
	public Bush1(int x, int y, double velX, double velY, String fileName) 
	{
		super(x, y, velX, velY, fileName);
	}
	
}
