import java.awt.Image;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;

public class Runner extends MovingImage {

    //private boolean jumpBush, slideGate, dodgeTrain;
    private boolean onSurface;
    private double velX, velY;
    
    public Runner(int x, int y)
    {	
   	 	super ("Stick-Running.gif", x, y, 100, 100);
    	
    	onSurface = false;
    	velX = 0;
    	velY = 0;
    }
    
    
    public void up()
    {
    		velY = -12;
    		moveByAmount(0, (int)velY);
    }
    
    public void down()
    {
    	velY = 12;
    	moveByAmount(0, (int)velY);
    }
    
    public void left()
    {
    	if((getX()-200)>0)
    	{
    		moveByAmount(-200, 0);
    	}
    		
    }
    
    public void right()
    {
    	if((getX()+getWidth()+200) <= 700)
    	{
    		moveByAmount(200, 0);
    	}
    }

    /*public void keyPressed(KeyEvent e)
    {
    	int code = e.getKeyCode();
    	
    	if (code == KeyEvent.VK_1)
    	{
    		runner.
    	}
    }*/
}
