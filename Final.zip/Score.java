import javax.swing.*;

import java.awt.Image;
import java.awt.event.*;
import java.awt.*;

public class Score extends JLabel {

	public int score; 
	//private Image background;

	public Score() 
	{
		int score = 0;
		setBounds(0, 0, 50, 50);
		//setBackground(Color.white);
	}

	public void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		//g.drawImage(background, 0, 0, 800, 700, this);
		String scr = "" + score;
		g.setColor(Color.BLACK);
		g.drawString(scr, 10, 10);
	}
	
	public String getScore()
	{
		return ""+score;
	}
	public void updateScore() 
	{
		score += 9;
	}

	public int toInt() {
		// TODO Auto-generated method stub
		return score;
	}
	

}








